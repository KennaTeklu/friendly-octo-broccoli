package com.peakform.fitness.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.peakform.fitness.core.LibraryExercise
import com.peakform.fitness.core.ProState
import com.peakform.fitness.engine.Library
import com.peakform.fitness.engine.OneRm
import com.peakform.fitness.engine.Stats
import com.peakform.fitness.ui.*
import com.peakform.fitness.ui.components.*

/**
 * Library — 1:1 port of #library-section (scr-library.md):
 * count header, search, group-by select, P4 streaming grid, collapsible group headers,
 * cards with difficulty badge + muscle tags + equipment + est. 1RM + Add to Workout,
 * detail sheet with instructions.
 */

@Composable
fun LibraryScreen(onAddToWorkout: (LibraryExercise) -> Unit) {
    val c = LocalProColors.current
    val ver = remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val l: () -> Unit = { ver.intValue++ }
        synchronized(ProState.listeners) { ProState.listeners.add(l) }
        onDispose {
            synchronized(ProState.listeners) { ProState.listeners.remove(l) }
        }
    }
    val _verTick = ver.intValue
    var search by remember { mutableStateOf("") }
    var groupBy by remember { mutableIntStateOf(0) }
    var openDetail by remember { mutableStateOf<LibraryExercise?>(null) }
    var collapsedGroups by remember(Library.groups) { mutableStateOf(Library.groups.keys.toSet()) }

    val mode = ProState.data.user.settings.trainingMode
    val all = remember(ver.intValue, mode) { Library.allLibraryExercises(mode).map { Library.augmented(it) } }

    val groupings = listOf("muscleGroup" to "Muscle", "equipment" to "Equipment", "difficulty" to "Difficulty")
    val filtered = remember(search, all) {
        if (search.length < 2) all
        else {
            val q = search.lowercase()
            all.filter { ex ->
                ex.name.lowercase().contains(q) ||
                    ex.muscles.any { it.lowercase().contains(q) } ||
                    ex.equipment.lowercase().contains(q) ||
                    ex.primaryMuscle.lowercase().contains(q)
            }
        }
    }

    val grouped: List<Pair<String, List<LibraryExercise>>> = remember(filtered, groupBy) {
        when (groupings[groupBy].first) {
            "equipment" -> filtered.groupBy { it.equipment }.toSortedMap().map { (k, v) -> k.replaceFirstChar { it.uppercase() } to v }
            "difficulty" -> {
                fun diff(sf: Double) = if (sf < 0.5) "Hard" else if (sf < 0.7) "Medium" else "Easy"
                listOf("Hard" to "Hard", "Medium" to "Medium", "Easy" to "Easy").mapNotNull { (label, key) ->
                    val list = filtered.filter { diff(it.skillFactor) == label }
                    if (list.isEmpty()) null else label to list
                }
            }
            else -> filtered.groupBy { it.primaryMuscle.ifBlank { "other" } }
                .toList()
                .sortedByDescending { it.second.size }
                .map { (k, v) -> k.replace('_', ' ').replaceFirstChar { it.uppercase() } to v }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Spacer(Modifier.height(4.dp))
        SectionTitle("fa-book-open", "Exercise Library")
        Text("${all.size} Movements Available", style = ProType.small, color = c.text3)

        ProTextField(value = search, onValueChange = { search = it }, placeholder = "Search exercises or muscles...")

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            groupings.forEachIndexed { i, (_, label) ->
                val active = groupBy == i
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(999.dp))
                        .background(if (active) c.accentSoft else c.surface2)
                        .border(1.dp, if (active) c.accentLine else c.hairline2, RoundedCornerShape(999.dp))
                        .clickable { groupBy = i }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, fontSize = 12.sp, color = if (active) c.accent else c.text2, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                }
            }
        }

        val cap = if (search.isNotBlank()) 200 else 60
        grouped.forEach { (group, list) ->
            val isCollapsed = group in collapsedGroups
            GlassCard(padding = PaddingValues(0.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable {
                        collapsedGroups = if (isCollapsed) collapsedGroups - group else collapsedGroups + group
                    }.padding(horizontal = 16.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(group, style = ProType.cardTitle, color = c.text, modifier = Modifier.weight(1f))
                    Text("(${list.size})", style = ProType.small, color = c.text3)
                    Spacer(Modifier.width(8.dp))
                    com.peakform.fitness.ui.FaIcon(if (isCollapsed) "fa-chevron-down" else "fa-chevron-up", size = 12.sp, tint = c.accent)
                }
                AnimatedVisibility(visible = !isCollapsed) {
                    Column(Modifier.padding(horizontal = 12.dp).padding(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        list.take(cap).forEach { ex ->
                            LibraryCard(ex, onOpen = { openDetail = ex }, onAdd = { onAddToWorkout(ex) })
                        }
                        if (list.size > cap) {
                            Text("Showing $cap of ${list.size} — refine search", style = ProType.small, color = c.text3)
                        }
                    }
                }
            }
        }
        if (filtered.isEmpty()) {
            EmptyState("fa-magnifying-glass", "No exercises match your search", "Try a different term or clear the filter.")
        }
        Spacer(Modifier.height(120.dp))
    }

    openDetail?.let { ex ->
        ExerciseDetailSheet(exercise = ex, onClose = { openDetail = null }, onAdd = {
            onAddToWorkout(ex)
            openDetail = null
        })
    }
}

@Composable
fun LibraryCard(ex: LibraryExercise, onOpen: () -> Unit, onAdd: () -> Unit) {
    val c = LocalProColors.current
    val record = ProState.data.exercises[ex.id]
    val difficulty = if (ex.skillFactor < 0.5) "Hard" else if (ex.skillFactor < 0.7) "Medium" else "Easy"
    val diffColor = when (difficulty) {
        "Hard" -> c.bad
        "Medium" -> c.warn
        else -> c.ok
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(c.surface2)
            .border(1.dp, c.hairline, RoundedCornerShape(14.dp))
            .clickable { onOpen() }
            .padding(13.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(ex.name, style = ProType.label, color = c.text, modifier = Modifier.weight(1f), fontSize = 14.sp)
            Box(Modifier.clip(RoundedCornerShape(999.dp)).background(diffColor.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                Text(difficulty, fontSize = 10.sp, color = diffColor, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ex.muscles.take(3).forEach { m ->
                Box(Modifier.clip(RoundedCornerShape(999.dp)).background(c.surface3).padding(horizontal = 8.dp, vertical = 2.dp)) {
                    Text(m.replace('_', ' '), fontSize = 10.sp, color = c.text3)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "${ex.defaultSets} × ${ex.defaultReps} · ${ex.equipment.replaceFirstChar { it.uppercase() }}",
            style = ProType.small, color = c.text3,
        )
        val mu = record?.mu
        if (mu != null && mu > 0) {
            Spacer(Modifier.height(4.dp))
            Text("Est. 1RM: ${mu.toInt()} lbs", style = ProType.small, color = c.accent)
        }
        Spacer(Modifier.height(10.dp))
        P4Button("Add to Workout", icon = "fa-plus", style = BtnStyle.INFO, minHeight = 36, modifier = Modifier.fillMaxWidth()) {
            onAdd()
        }
    }
}

@Composable
fun ExerciseDetailSheet(exercise: LibraryExercise, onClose: () -> Unit, onAdd: () -> Unit) {
    val c = LocalProColors.current
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onClose,
        containerColor = c.glass2,
        shape = RoundedCornerShape(22.dp),
        title = { Text(exercise.name, style = ProType.cardTitle, color = c.text) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Muscles: ${exercise.muscles.joinToString(", ") { it.replace('_', ' ') }}", style = ProType.small, color = c.text2)
                Text("Equipment: ${exercise.equipment} · Sets: ${exercise.defaultSets} × ${exercise.defaultReps}", style = ProType.small, color = c.text2)
                if (exercise.progression.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Progression: ${exercise.progression}", style = ProType.small, color = c.text3)
                }
                if (exercise.instructions.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("How to do it", style = ProType.label, color = c.text)
                    exercise.instructions.forEachIndexed { i, step ->
                        Text("${i + 1}. ${step.replace(Regex("<[^>]*>"), "")}", style = ProType.small, color = c.text2, modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        },
        confirmButton = { P4Button("Add to Workout", onClick = onAdd, style = BtnStyle.PRIMARY, minHeight = 40) },
        dismissButton = { P4Button("Close", onClick = onClose, style = BtnStyle.SECONDARY, minHeight = 40) },
    )
}
