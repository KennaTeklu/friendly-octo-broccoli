package com.peakform.fitness.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.peakform.fitness.core.ProState
import com.peakform.fitness.core.WorkoutExercise
import com.peakform.fitness.core.WorkoutRecord
import com.peakform.fitness.engine.Generator
import com.peakform.fitness.engine.Library
import com.peakform.fitness.engine.OneRm
import com.peakform.fitness.engine.Sessions
import com.peakform.fitness.ui.*
import com.peakform.fitness.ui.components.*
import kotlinx.coroutines.launch

/**
 * Workout — 1:1 port of #workout-section with the P4 card system (scr-workout.md):
 * chips row, collapsible details, P4 collapsible exercise cards (one open at a time,
 * state badges: Needs 1RM / Started / Ready / skipped / done), prescription block,
 * logger (weight stepper, sets, per-set reps, RPE chips), complete-workout flow,
 * rest-timer overlay, no-workout empty state.
 */

@Composable
fun WorkoutScreen(
    onRequireGenerate: () -> Unit,
    onOpenSection: (String) -> Unit,
) {
    val c = LocalProColors.current
    val scope = rememberCoroutineScope()
    val ver = remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val l: () -> Unit = { ver.intValue++ }
        synchronized(ProState.listeners) { ProState.listeners.add(l) }
        onDispose {
            synchronized(ProState.listeners) { ProState.listeners.remove(l) }
        }
    }
    val _verTick = ver.intValue

    var openCardIndex by remember { mutableIntStateOf(-1) }
    var showDetails by remember { mutableStateOf(false) }
    var completeDialog by remember { mutableStateOf(false) }
    var celebration by remember { mutableStateOf<Sessions.CompletionResult?>(null) }
    // FIX (audit): remove/skip now require confirmation (engine ships the verbatim strings)
    var confirmRemove by remember { mutableStateOf<Int?>(null) }
    var confirmSkip by remember { mutableStateOf<Int?>(null) }

    val workout = ProState.currentWorkout
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(4.dp))
        Text("Today's Workout", style = ProType.sectionTitle, color = c.text)

        // chips row
        if (workout != null && workout.exercises.isNotEmpty()) {
            // FIX (audit): chipData was recomputed 5× per render — hoist to a single val.
            val chips = remember(workout.id, ver.intValue) { Generator.chipData(workout) }
            if (chips != null) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    P4Chip(chips.name, icon = "fa-dumbbell")
                    P4Chip(chips.focus, icon = "fa-crosshairs")
                    P4Chip("${chips.estTime}-${chips.estTime + 15} min", icon = "fa-clock")
                    P4Chip(chips.intensity, icon = "fa-gauge-high")
                    if (chips.deload && notifFlag("deload_notice")) P4Chip("Deload", icon = "fa-leaf", tint = c.warn)
                    if (chips.taper) P4Chip("Taper", icon = "fa-feather", tint = c.ok)
                }
            }

            // details collapsible
            GlassCard(padding = PaddingValues(14.dp), onClick = { showDetails = !showDetails }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("View details", style = ProType.label, color = c.text, modifier = Modifier.weight(1f))
                    com.peakform.fitness.ui.FaIcon(if (showDetails) "fa-chevron-up" else "fa-chevron-down", size = 13.sp, tint = c.accent)
                }
                AnimatedVisibility(visible = showDetails) {
                    Column {
                        Spacer(Modifier.height(8.dp))
                        KeyValueRow("Workout Type", workout.name)
                        KeyValueRow("Focus", chips?.focus ?: "Full Body")
                        KeyValueRow("Estimated Time", "${(chips?.estTime ?: 0)}-${(chips?.estTime ?: 0) + 15} minutes")
                        KeyValueRow("Intensity", chips?.intensity ?: "Moderate")
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Rest 60–90 seconds between sets. Warm up before your first exercise, stretch after.",
                            style = ProType.small, color = c.text3,
                        )
                    }
                }
            }

            // exercise cards
            workout.exercises.forEachIndexed { index, ex ->
                ExerciseCard(
                    index = index,
                    exercise = ex,
                    workoutId = workout.id,
                    expanded = openCardIndex == index,
                    onToggle = { openCardIndex = if (openCardIndex == index) -1 else index },
                    onLogged = {
                        ver.intValue++
                        ProState.notifyChanged()
                        // FIX (audit): the haptics power toggle persisted but nothing read it —
                        // buzz on every logged effort now.
                        if (powerFlag("haptics", default = true)) {
                            try {
                                val v = com.peakform.fitness.ui.Fa.appContext?.getSystemService(android.content.Context.VIBRATOR_SERVICE) as? android.os.Vibrator
                                v?.vibrate(android.os.VibrationEffect.createOneShot(18, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                            } catch (_: Exception) {}
                        }
                        // FIX (audit): rest timer now honors the autoRest power setting and lives
                        // in the app-scope RestTimer holder (survives tab switches).
                        if (powerFlag("autoRest", default = true)) {
                            RestTimer.start(ProState.data.user.settings.restTime)
                        }
                        val w = ProState.currentWorkout
                        if (w != null && w.exercises.all { it.isLogged }) {
                            completeDialog = true
                        } else {
                            // advance to next unlogged
                            openCardIndex = w?.exercises?.indexOfFirst { !it.isLogged } ?: -1
                        }
                    },
                    onSkip = { notes ->
                        val w = ProState.currentWorkout ?: return@ExerciseCard
                        ProState.currentWorkout = Sessions.skipExercise(w, index, notes)
                        ProState.performSave()
                        ver.intValue++
                        ProState.notifyChanged()
                    },
                    onRemove = {
                        // FIX (audit): one accidental tap deleted the exercise — confirm first.
                        confirmRemove = index
                    },
                    onAskSkip = {
                        confirmSkip = index
                    },
                    onStartRest = { sec -> RestTimer.start(sec) },
                )
            }

            // complete button
            val allLogged = workout.exercises.isNotEmpty() && workout.exercises.all { it.isLogged }
            if (allLogged) {
                LuxuryStartButton("Complete & Log Today's Workout", "fa-trophy", onClick = {
                    completeDialog = true
                }, modifier = Modifier.fillMaxWidth())
            }
        } else {
            EmptyState(
                icon = "fa-dumbbell",
                title = "No Workout Scheduled",
                message = "Generate a workout to get started with today's training.",
            )
            Spacer(Modifier.height(4.dp))
            P4Button("Generate Workout", onClick = onRequireGenerate, icon = "fa-bolt", modifier = Modifier.fillMaxWidth())
        }

        Spacer(Modifier.height(16.dp))
    }

    // ---- rest timer overlay (app-scope — survives navigation) ----
    if (RestTimer.running) {
        RestTimerOverlay(
            secondsLeft = RestTimer.secondsLeft,
            total = RestTimer.total,
            onAdd15 = { RestTimer.add15() },
            onDone = { RestTimer.stop() },
        )
    }

    // ---- remove confirmation (verbatim engine strings) ----
    confirmRemove?.let { idx ->
        val w = ProState.currentWorkout
        val name = w?.exercises?.getOrNull(idx)?.name ?: ""
        SwalDialog(
            title = Sessions.REMOVE_TITLE,
            text = Sessions.removeConfirmText(name),
            confirmText = "Remove",
            cancelText = "Cancel",
            onConfirm = {
                confirmRemove = null
                val cur = ProState.currentWorkout ?: return@SwalDialog
                ProState.currentWorkout = Sessions.removeExerciseFromWorkout(cur, idx)
                ProState.performSave()
                if (openCardIndex == idx) openCardIndex = -1
                ver.intValue++
                ProState.notifyChanged()
            },
            onDismiss = { confirmRemove = null },
        )
    }

    // ---- skip confirmation ----
    confirmSkip?.let { idx ->
        val w = ProState.currentWorkout
        val name = w?.exercises?.getOrNull(idx)?.name ?: ""
        SwalDialog(
            title = Sessions.SKIP_TITLE,
            text = Sessions.skipConfirmText(name),
            confirmText = "Skip it",
            cancelText = "Cancel",
            onConfirm = {
                confirmSkip = null
                val cur = ProState.currentWorkout ?: return@SwalDialog
                ProState.currentWorkout = Sessions.skipExercise(cur, idx, "Skipped - user choice")
                ProState.performSave()
                ver.intValue++
                ProState.notifyChanged()
            },
            onDismiss = { confirmSkip = null },
        )
    }

    // ---- complete confirmation ----
    if (completeDialog && workout != null) {
        val unlogged = Sessions.unloggedExercises(workout)
        SwalDialog(
            title = if (unlogged.isEmpty()) "Complete Workout 🏆" else "⚠️ Unlogged Exercises",
            text = if (unlogged.isEmpty()) "Log this session and update your progression?"
            else "These exercises are not logged: ${unlogged.joinToString(", ")}. Complete anyway?",
            confirmText = "Yes, complete it",
            cancelText = "No, go back",
            onConfirm = {
                completeDialog = false
                scope.launch {
                    val result = Sessions.completeWorkout(workout, generateNext = true)
                    celebration = result
                    ProState.notifyChanged()
                }
            },
            onDismiss = { completeDialog = false },
        )
    }

    // ---- celebration ----
    celebration?.let { result ->
        CelebrationDialog(result = result, onDismiss = { celebration = null })
    }
}

@Composable
fun ExerciseCard(
    index: Int,
    exercise: WorkoutExercise,
    workoutId: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    onLogged: () -> Unit,
    onAskSkip: () -> Unit,
    onSkip: (String) -> Unit,
    onRemove: () -> Unit,
    onStartRest: (Int) -> Unit,
) {
    val c = LocalProColors.current
    val isDrill = exercise.noFatigue || exercise.isWarmup || exercise.isCooldown || exercise.isComponentDrill

    // card state
    val has1RM = (ProState.data.exercises[exercise.id]?.tested1RM ?: 0.0) > 0
    val state = when {
        exercise.skipped -> "skipped"
        exercise.actual != null -> "done"
        !isDrill && !has1RM -> "needs1rm"
        else -> "ready"
    }
    val borderColor = when (state) {
        "needs1rm" -> c.warn
        "done" -> c.ok
        else -> c.hairline
    }
    val shape = RoundedCornerShape(18.dp)

    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.surface)
            .border(2.dp, borderColor, shape)
            .padding(16.dp),
    ) {
        // header — the toggle target (FIX (audit): the whole card used to be clickable, so a
        // stray tap on labels/paddings collapsed the open logger and destroyed all input).
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable { onToggle() },
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(exercise.name, style = ProType.exerciseTitle, color = c.text, modifier = Modifier.weight(1f, fill = false))
                    Spacer(Modifier.width(8.dp))
                    if (state == "needs1rm") {
                        Box(Modifier.clip(RoundedCornerShape(999.dp)).background(c.warn.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("Needs 1RM", color = c.warn, fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    } else if (state == "done") {
                        Box(Modifier.clip(RoundedCornerShape(999.dp)).background(c.ok.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("✓ Logged", color = c.ok, fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    } else if (exercise.skipped) {
                        Box(Modifier.clip(RoundedCornerShape(999.dp)).background(c.surface3).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("Skipped", color = c.text3, fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    } else if (exercise.isWarmup) {
                        Box(Modifier.clip(RoundedCornerShape(999.dp)).background(c.accentSoft).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("Warm-up", color = c.accent, fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    } else if (exercise.isCooldown) {
                        Box(Modifier.clip(RoundedCornerShape(999.dp)).background(c.accentSoft).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("Cooldown", color = c.accent, fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                // FIX (audit): long muscle names could clip — scroll horizontally.
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                ) {
                    exercise.muscleGroup.take(3).forEach { m ->
                        Box(Modifier.clip(RoundedCornerShape(999.dp)).background(c.surface2).border(1.dp, c.hairline2, RoundedCornerShape(999.dp)).padding(horizontal = 9.dp, vertical = 3.dp)) {
                            Text(m.replace('_', ' '), fontSize = 12.sp, color = c.text2)
                        }
                    }
                }
            }
            com.peakform.fitness.ui.FaIcon(if (expanded) "fa-chevron-up" else "fa-chevron-down", size = 14.sp, tint = c.accent)
        }

        // prescription summary (always visible) — also a toggle target
        Spacer(Modifier.height(12.dp))
        val rx = exercise.prescribed
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onToggle() }) {
            if (exercise.prescriptionType == "time" || exercise.defaultDuration != null) {
                RxLine(label = "HOLD", value = "${rx.duration?.toInt() ?: 45}s × ${rx.sets} sets")
            } else {
                val w = rx.weight
                RxLine(
                    label = "PRESCRIPTION",
                    value = (if (w != null && w > 0) "${OneRm.roundToNearest(w).toInt()} lbs · " else "") + "${rx.sets} × ${rx.reps}",
                )
            }
        }

        AnimatedVisibility(visible = expanded) {
            Column {
                Spacer(Modifier.height(12.dp))
                if (exercise.progressionNotes.isNotBlank()) {
                    Text(exercise.progressionNotes, style = ProType.small, color = c.text3)
                    Spacer(Modifier.height(10.dp))
                }
                if (exercise.skipped) {
                    Text("Skipped — ${exercise.actual?.notes ?: ""}", style = ProType.body2, color = c.text3)
                } else if (exercise.actual != null) {
                    val a = exercise.actual!!
                    Text(
                        buildString {
                            append("Logged: ${a.sets} sets")
                            if (a.reps.isNotEmpty()) append(" × ${a.reps.joinToString(", ") { com.peakform.fitness.core.ProJson.formatNum(it) }} reps")
                            if (a.weight > 0) append(" @ ${a.weight.toInt()} lbs")
                            if (a.volume != null) append(" · ${com.peakform.fitness.engine.Stats.formatNumber(a.volume!!)} lbs volume")
                        },
                        style = ProType.body2, color = c.ok,
                    )
                } else {
                    if (!isDrill && !has1RM) {
                        OneRmTestPanel(
                            exerciseId = exercise.id,
                            onDone = { onLogged() },
                            onSkip = { onAskSkip() },
                            onStartRest = onStartRest,
                        )
                    } else {
                        LoggerPanel(
                            exercise = exercise,
                            onSave = { actual, notes ->
                                val w = ProState.currentWorkout ?: return@LoggerPanel
                                val result = Sessions.applyPerformance(w, index, actual, notes)
                                if (result.ok && result.workout != null) {
                                    ProState.currentWorkout = result.workout
                                    ProState.performSave()
                                }
                                onLogged()
                            },
                            onStartRest = onStartRest,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        P4Button("Skip", onClick = onAskSkip, style = BtnStyle.GHOST, minHeight = 40, modifier = Modifier.weight(1f))
                        if (!exercise.isWarmup && !exercise.isCooldown) {
                            P4Button("Remove", onClick = onRemove, style = BtnStyle.GHOST, minHeight = 40, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

/** Reads a boolean from the p4_power_settings JSON (default when absent). */
internal fun powerFlag(key: String, default: Boolean): Boolean {
    val ctx = com.peakform.fitness.ui.Fa.appContext ?: return default
    return try {
        val raw = com.peakform.fitness.core.ProPrefs.get(ctx, "p4_power_settings") ?: return default
        val o = com.peakform.fitness.core.ProJson.json.parseToJsonElement(raw) as kotlinx.serialization.json.JsonObject
        val p = (o[key] as? kotlinx.serialization.json.JsonPrimitive)?.content ?: return default
        p != "false"
    } catch (_: Exception) {
        default
    }
}

/** Reads a notification preference (p4_notif_<key>, absent = on) — FIX (audit): the
 * Settings notification toggles persisted but nothing read them; the retest banner and
 * the Deload chip are now wired to their switches. */
internal fun notifFlag(key: String, default: Boolean = true): Boolean {
    val ctx = com.peakform.fitness.ui.Fa.appContext ?: return default
    return com.peakform.fitness.core.ProPrefs.get(ctx, "p4_notif_$key") != "false"
}

@Composable
fun RxLine(label: String, value: String) {
    val c = LocalProColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(c.glass2)
            .border(1.dp, c.hairline2, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(label, fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, letterSpacing = 0.8.sp, color = c.accent)
        Spacer(Modifier.height(2.dp))
        Text(value, fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold, color = c.accent, fontFamily = SpaceGrotesk)
    }
}
